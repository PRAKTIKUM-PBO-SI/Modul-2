
package Perulangan;

/**
 *@author Teddy Putratama
 * 2211103067
 * 07C
 */

public class ForLoopExample {
    public static void main(String[] args){
        for (int i = 1; i <= 10; i++){
            System.out.println("Perulangan ke= " + i);
        }
    }
}
