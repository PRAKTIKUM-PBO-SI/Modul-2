
package Perulangan;

/**
 *
 * @author Teddy Putratama
 * 2211103067
 * 07C
 */
public class WhileLoopExample {
    public static void main (String[] args){
        int i = 1;
        while (i<=5){
        System.out.println("Perulangan Ke = " + i);
        i++;
        }
    }
}
