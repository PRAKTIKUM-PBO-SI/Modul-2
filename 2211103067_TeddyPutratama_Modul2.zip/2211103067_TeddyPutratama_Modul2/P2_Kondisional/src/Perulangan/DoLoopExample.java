
package Perulangan;

/**
 *
 * @author @author Teddy Putratama
 * 2211103067
 * 07C
 */
public class DoLoopExample {
    public static void main (String[] args){
        int i = 1;
        do {
           System.out.println("Perulangan Ke = " + i);
           i++;
        }while (i<=5);
    }
}
