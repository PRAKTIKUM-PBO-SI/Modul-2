
package kondisional2;
import java.util.Scanner;

/**
 *@author Teddy Putratama
 * 2211103067
 * 07C
 */
public class Main {
    public static void main (String[] args){
        Scanner input = new Scanner (System.in);
        Hari ph = new Hari ();
        
        System.out.println("Masukan angka (1-7):");
        ph.hari = input.nextInt();
        ph.pilihanHari();
    }
    
}
