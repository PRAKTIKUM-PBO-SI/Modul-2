
package kondisional2;

/**
 *@author Teddy Putratama
 * 2211103067
 * 07C
 */
public class Hari {
    int hari;
    
    void pilihanHari(){
        switch (hari){
            case 1 : System.out.println("Minggu");break;
            case 2 : System.out.println("Senin");break;
            case 3 : System.out.println("Selasa");break;
            case 4 : System.out.println("Rabu");break;
            case 5 : System.out.println("Kamis");break;
            case 6 : System.out.println("Jumat");break;
            case 7 : System.out.println("Sabtu");break;
            default : System.out.println("Hari Tidak Valid");break;
            
            
        }
       
    }
    
}
