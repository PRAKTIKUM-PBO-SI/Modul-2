
package p2_kondisional;

/**
 *@author Teddy Putratama
 * 2211103067
 * 07C
 */
public class CekBilangan {
    int bilangan;
    
    void periksaGenapGanjil(){
        if (bilangan % 2==0){
            System.out.println (bilangan + "adalah bilangan genap");
        }else{
            System.out.println( bilangan + "adalah bilangan ganjil");
        }
    }
    
}
