
package p2_kondisional;

/**
 *@author Teddy Putratama
 * 2211103067
 * 07C
 */
public class Main {
    public static void main (String[] Args){
        CekBilangan cb = new CekBilangan();
        cb.bilangan=10;
        cb.periksaGenapGanjil();
    }
    
}
