/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package UnguidedP4Wildan;

import java.util.Scanner;

/**
 *
 * @author Wildan Restu Saputra
 * 2311103136
 * S1SI-07-C
 */
public class UnguidedLatihanP4Wildan {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Pesanan pesanan = new Pesanan(10); // Maksimal 10 pesanan
        char tambahPesanan;
// Perulangan untuk menambah pesanan
        do {
            System.out.print("Masukkan nama item: ");
            String namaItem = scanner.nextLine();
            System.out.print("Masukkan harga item: ");
            double hargaItem = scanner.nextDouble();
            int kategoriItem = 0;
            boolean kategori = false;
            while(kategori == false){
            System.out.print("Masukkan kategori (1: Pembuka, 2: Utama, 3: Minuman): "); kategoriItem= scanner.nextInt();
            if(kategoriItem<=3){
                kategori = true;
            } else{
                System.out.println("kategori salah input");
            }
            }
            
            scanner.nextLine(); // Bersihkan buffer
            Menu item = new Menu(namaItem, hargaItem, kategoriItem);
            pesanan.tambahPesanan(item);
            System.out.print("Apakah ingin menambah pesanan lagi? (y/n):");
            tambahPesanan = scanner.next().charAt(0);
            
            scanner.nextLine(); // Bersihkan buffer
        } while (tambahPesanan == 'y' || tambahPesanan == 'Y');
        System.out.println("");
// Tampilkan pesanan dan hitung diskon
        pesanan.tampilkanPesanan();
        double diskon = pesanan.hitungDiskon();
        if (diskon > 0) {
            System.out.println("Anda mendapatkan diskon 10% sebesar Rp " + diskon);
        }
        System.out.println("Total yang harus dibayar: Rp " + (pesanan.totalHarga - diskon));
    }
}